import { CharacterScreen } from "@/components/screens/character-screen";

export default async function CharacterPage({
  params,
}: {
  params: Promise<{ characterId: string }>;
}) {
  const { characterId } = await params;
  return <CharacterScreen characterId={characterId} />;
}
