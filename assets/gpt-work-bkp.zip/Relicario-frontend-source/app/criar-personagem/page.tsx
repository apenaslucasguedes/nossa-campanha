import { CreateCharacterScreen } from "@/components/screens/create-character-screen";

export default function CreateCharacterPage() {
  return <CreateCharacterScreen />;
}
