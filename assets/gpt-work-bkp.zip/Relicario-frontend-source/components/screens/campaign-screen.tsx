"use client";

import Link from "next/link";
import { campaignToMarkdown, downloadMarkdown } from "@/lib/markdown";
import { useRelicario } from "@/app/providers";
import {
  CharacterIdentity,
  MechanicalSummary,
} from "@/components/character-parts";
import { SystemIcon } from "@/components/system-icon";
import { Button, EmptyMessage, PageHeader, SectionCard, StatusTag } from "@/components/ui";

export function CampaignScreen({ campaignId }: { campaignId: string }) {
  const { state, hydrated, linkCharacter, setActiveCampaign, announce } =
    useRelicario();

  if (!hydrated) {
    return (
      <SectionCard title="Carregando campanha">
        <p className="muted">Recuperando os registros deste dispositivo.</p>
      </SectionCard>
    );
  }

  const campaign = state.campaigns.find((item) => item.id === campaignId);

  if (!campaign) {
    return (
      <SectionCard title="Campanha não encontrada">
        <EmptyMessage title="Registro indisponível">
          O endereço não corresponde a uma campanha salva neste dispositivo.
        </EmptyMessage>
        <Link className="button button-primary" href="/campanhas">
          Voltar às campanhas
        </Link>
      </SectionCard>
    );
  }

  const linkedCharacters = campaign.characterIds.map((id) =>
    state.characters.find((character) => character.id === id),
  );

  const exportCampaign = () => {
    downloadMarkdown(
      campaign.id + ".md",
      campaignToMarkdown(campaign, state.characters),
    );
    announce("Pacote Markdown da campanha exportado.");
  };

  return (
    <>
      <div className="breadcrumb">
        <Link href="/campanhas">Campanhas</Link>
        <span>/</span>
        <span>{campaign.name}</span>
      </div>
      <PageHeader
        eyebrow={campaign.region}
        title={campaign.name}
        description={campaign.summary}
        actions={
          <>
            <StatusTag tone={campaign.status === "active" ? "active" : "paused"}>
              {campaign.status === "active" ? "Ativa" : "Pausada"}
            </StatusTag>
            {campaign.id !== state.activeCampaignId ? (
              <Button variant="secondary" onClick={() => setActiveCampaign(campaign.id)}>
                Tornar ativa
              </Button>
            ) : null}
            <Button onClick={exportCampaign}>
              <SystemIcon name="exportPackage" size={18} />
              Exportar pacote Markdown
            </Button>
          </>
        }
      />

      <div className="campaign-detail-layout">
        <div className="campaign-detail-main">
          <SectionCard
            eyebrow="Dupla"
            title="Dois personagens"
            action={<span className="card-note">Um personagem por jogador</span>}
          >
            <div className="linked-character-grid">
              {linkedCharacters.map((character, seat) => (
                <article className="linked-character" key={seat}>
                  <div className="linked-character-topline">
                    <span>Assento {seat + 1}</span>
                    <select
                      value={character?.id ?? ""}
                      onChange={(event) =>
                        linkCharacter(
                          campaign.id,
                          seat as 0 | 1,
                          event.target.value || null,
                        )
                      }
                      aria-label={"Vincular personagem ao assento " + (seat + 1)}
                    >
                      <option value="">Assento livre</option>
                      {state.characters
                        .filter((item) => item.status !== "archived")
                        .map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.name} · {item.className}
                          </option>
                        ))}
                    </select>
                  </div>
                  {character ? (
                    <>
                      <CharacterIdentity character={character} size="large" />
                      <MechanicalSummary character={character} />
                      <Link
                        className="text-link"
                        href={"/personagem/" + character.id}
                      >
                        Abrir ficha completa
                      </Link>
                    </>
                  ) : (
                    <EmptyMessage title="Assento livre">
                      Escolha um personagem disponível na biblioteca.
                    </EmptyMessage>
                  )}
                </article>
              ))}
            </div>
          </SectionCard>

          <div className="split-grid">
            <SectionCard eyebrow="Descobertas" title="Locais revelados">
              <ul className="record-list">
                {campaign.revealedLocations.length ? (
                  campaign.revealedLocations.map((location) => (
                    <li key={location}>
                      <SystemIcon name="revealedLocation" size={18} />
                      {location}
                    </li>
                  ))
                ) : (
                  <li className="muted">Nenhum local menor revelado.</li>
                )}
              </ul>
            </SectionCard>

            <SectionCard eyebrow="Registro" title="Missões provisórias">
              <ul className="record-list numbered">
                {campaign.provisionalMissions.length ? (
                  campaign.provisionalMissions.map((mission) => (
                    <li key={mission}>
                      <SystemIcon name="mission" size={18} />
                      {mission}
                    </li>
                  ))
                ) : (
                  <li className="muted">Nenhuma missão provisória.</li>
                )}
              </ul>
            </SectionCard>
          </div>
        </div>

        <aside className="campaign-detail-side">
          <SectionCard eyebrow="Referência" title="Chat do GPT Mestre">
            <p className="reference-text">
              {campaign.chatReference || "Nenhuma referência vinculada."}
            </p>
            <small className="muted">
              O Relicário registra o estado. A condução permanece no chat.
            </small>
          </SectionCard>

          <SectionCard eyebrow="Acessos" title="Campanha em jogo">
            <div className="stacked-actions">
              <Link className="feature-link feature-link-map" href="/mapa">
                <span>
                  <small>Exploração</small>
                  <strong>Abrir mapa</strong>
                </span>
                <b>↗</b>
              </Link>
              <Link className="feature-link feature-link-table" href="/mesa">
                <span>
                  <small>Estado compartilhado</small>
                  <strong>Abrir mesa</strong>
                </span>
                <b>↗</b>
              </Link>
            </div>
          </SectionCard>
        </aside>
      </div>
    </>
  );
}
