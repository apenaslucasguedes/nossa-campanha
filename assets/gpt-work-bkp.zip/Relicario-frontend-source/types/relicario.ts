export type AttributeName =
  | "Força"
  | "Agilidade"
  | "Intelecto"
  | "Presença"
  | "Instinto";

export type CharacterClass =
  | "Guerreiro"
  | "Arcanista"
  | "Lâmina Sombria"
  | "Necromante"
  | "Bardo"
  | "Druida";

export type ClassResource =
  | "Vigor"
  | "Foco"
  | "Ímpeto"
  | "Essência"
  | "Inspiração"
  | "Seiva";

export type Condition =
  | "Ferido"
  | "Exausto"
  | "Amedrontado"
  | "Envenenado"
  | "Imobilizado"
  | "Desorientado"
  | "Corrompido";

export type CampaignStatus = "active" | "paused";
export type CharacterStatus = "available" | "linked" | "retired" | "archived";
export type Zone = "Corpo a corpo" | "Perto" | "Distante" | "Fora de alcance";

export interface Attributes {
  Força: number;
  Agilidade: number;
  Intelecto: number;
  Presença: number;
  Instinto: number;
}

export interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  note?: string;
}

export interface Ability {
  id: string;
  name: string;
  description: string;
}

export interface Character {
  id: string;
  name: string;
  player: string;
  pronouns: string;
  className: CharacterClass;
  origin: string;
  level: number;
  attributes: Attributes;
  vitality: { current: number; max: number };
  resource: { name: ClassResource; current: number; max: number };
  defense: number;
  inventory: {
    used: number;
    capacity: number;
    items: InventoryItem[];
  };
  specialties: string[];
  abilities: Ability[];
  conditions: Condition[];
  appearance: string;
  personality: string;
  objective: string;
  fear: string;
  initialBond: string;
  currentBond: string;
  status: CharacterStatus;
  campaignId: string | null;
  color: string;
  accent: string;
  mechanicsPending?: boolean;
}

export interface Campaign {
  id: string;
  name: string;
  status: CampaignStatus;
  region: string;
  characterIds: [string | null, string | null];
  summary: string;
  revealedLocations: string[];
  provisionalMissions: string[];
  chatReference: string;
}

export interface Region {
  name: string;
  metropolis: string;
  x: number;
  y: number;
  tone: string;
}

export interface ActionRecord {
  id: string;
  time: string;
  actor: string;
  text: string;
  roll?: number;
}

export interface Enemy {
  id: string;
  name: string;
  vitality: number;
  vitalityMax: number;
  zone: Zone;
  conditions: Condition[];
}

export interface DemoState {
  characters: Character[];
  campaigns: Campaign[];
  activeCampaignId: string;
  revealedPointIds: string[];
  history: ActionRecord[];
  enemies: Enemy[];
}

export interface NewCampaignInput {
  name: string;
  region: string;
}

export interface NewCharacterInput {
  name: string;
  player: string;
  pronouns: string;
  className: CharacterClass;
  origin: string;
  attributes: Attributes;
  specialties: string[];
  appearance: string;
  personality: string;
  objective: string;
  fear: string;
  initialBond: string;
  currentBond: string;
  color: string;
  accent: string;
}
