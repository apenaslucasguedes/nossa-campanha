"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { CLASS_RESOURCE, INITIAL_STATE } from "@/data/relicario";
import { clearDemoState, loadDemoState, saveDemoState } from "@/lib/storage";
import type {
  Condition,
  DemoState,
  NewCampaignInput,
  NewCharacterInput,
} from "@/types/relicario";

interface RelicarioContextValue {
  state: DemoState;
  hydrated: boolean;
  notice: string;
  dismissNotice: () => void;
  announce: (message: string) => void;
  adjustVitality: (characterId: string, amount: number) => void;
  adjustResource: (characterId: string, amount: number) => void;
  addCondition: (characterId: string, condition: Condition) => void;
  removeCondition: (characterId: string, condition: Condition) => void;
  rollD20: (actor?: string) => number;
  createCampaign: (input: NewCampaignInput) => string;
  setActiveCampaign: (campaignId: string) => void;
  linkCharacter: (
    campaignId: string,
    seat: 0 | 1,
    characterId: string | null,
  ) => void;
  createCharacter: (input: NewCharacterInput) => string;
  duplicateCharacter: (characterId: string) => void;
  archiveCharacter: (characterId: string) => void;
  adjustEnemyVitality: (enemyId: string, amount: number) => void;
  resetDemo: () => void;
}

const RelicarioContext = createContext<RelicarioContextValue | null>(null);

const now = () =>
  new Intl.DateTimeFormat("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date());

const uniqueId = (prefix: string) =>
  prefix + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 6);

export function RelicarioProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<DemoState>(INITIAL_STATE);
  const [hydrated, setHydrated] = useState(false);
  const [notice, setNotice] = useState("");
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      const stored = loadDemoState();
      if (stored) setState(stored);
      setHydrated(true);
    });
    return () => window.cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    if (hydrated) saveDemoState(state);
  }, [hydrated, state]);

  const announce = useCallback((message: string) => {
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    setNotice(message);
    noticeTimer.current = setTimeout(() => setNotice(""), 3200);
  }, []);

  const dismissNotice = useCallback(() => setNotice(""), []);

  const adjustVitality = useCallback((characterId: string, amount: number) => {
    setState((current) => ({
      ...current,
      characters: current.characters.map((character) =>
        character.id === characterId
          ? {
              ...character,
              vitality: {
                ...character.vitality,
                current: Math.max(
                  0,
                  Math.min(character.vitality.max, character.vitality.current + amount),
                ),
              },
            }
          : character,
      ),
      history: [
        {
          id: uniqueId("history"),
          time: now(),
          actor:
            current.characters.find((character) => character.id === characterId)?.name ??
            "Personagem",
          text: "Vitalidade alterada: " + (amount > 0 ? "+" : "") + amount,
        },
        ...current.history,
      ].slice(0, 30),
    }));
  }, []);

  const adjustResource = useCallback((characterId: string, amount: number) => {
    setState((current) => ({
      ...current,
      characters: current.characters.map((character) =>
        character.id === characterId
          ? {
              ...character,
              resource: {
                ...character.resource,
                current: Math.max(
                  0,
                  Math.min(character.resource.max, character.resource.current + amount),
                ),
              },
            }
          : character,
      ),
      history: [
        {
          id: uniqueId("history"),
          time: now(),
          actor:
            current.characters.find((character) => character.id === characterId)?.name ??
            "Personagem",
          text: "Recurso alterado: " + (amount > 0 ? "+" : "") + amount,
        },
        ...current.history,
      ].slice(0, 30),
    }));
  }, []);

  const addCondition = useCallback((characterId: string, condition: Condition) => {
    setState((current) => ({
      ...current,
      characters: current.characters.map((character) =>
        character.id === characterId && !character.conditions.includes(condition)
          ? { ...character, conditions: [...character.conditions, condition] }
          : character,
      ),
      history: [
        {
          id: uniqueId("history"),
          time: now(),
          actor:
            current.characters.find((character) => character.id === characterId)?.name ??
            "Personagem",
          text: "Condição adicionada: " + condition,
        },
        ...current.history,
      ].slice(0, 30),
    }));
  }, []);

  const removeCondition = useCallback((characterId: string, condition: Condition) => {
    setState((current) => ({
      ...current,
      characters: current.characters.map((character) =>
        character.id === characterId
          ? {
              ...character,
              conditions: character.conditions.filter((item) => item !== condition),
            }
          : character,
      ),
      history: [
        {
          id: uniqueId("history"),
          time: now(),
          actor:
            current.characters.find((character) => character.id === characterId)?.name ??
            "Personagem",
          text: "Condição removida: " + condition,
        },
        ...current.history,
      ].slice(0, 30),
    }));
  }, []);

  const rollD20 = useCallback((actor = "Mesa") => {
    const result = Math.floor(Math.random() * 20) + 1;
    setState((current) => ({
      ...current,
      history: [
        {
          id: uniqueId("history"),
          time: now(),
          actor,
          text: "Rolagem de d20",
          roll: result,
        },
        ...current.history,
      ].slice(0, 30),
    }));
    announce("d20: " + result);
    return result;
  }, [announce]);

  const createCampaign = useCallback(
    (input: NewCampaignInput) => {
      const id = uniqueId("campanha");
      setState((current) => ({
        ...current,
        campaigns: [
          ...current.campaigns,
          {
            id,
            name: input.name.trim() || "Nova campanha",
            status: "paused",
            region: input.region,
            characterIds: [null, null],
            summary: "Campanha criada para vincular dois personagens.",
            revealedLocations: [],
            provisionalMissions: [],
            chatReference: "",
          },
        ],
      }));
      announce("Campanha criada e salva neste dispositivo.");
      return id;
    },
    [announce],
  );

  const setActiveCampaign = useCallback(
    (campaignId: string) => {
      setState((current) => ({
        ...current,
        activeCampaignId: campaignId,
        campaigns: current.campaigns.map((campaign) => ({
          ...campaign,
          status: campaign.id === campaignId ? "active" : "paused",
        })),
      }));
      announce("Campanha ativa alterada.");
    },
    [announce],
  );

  const linkCharacter = useCallback(
    (campaignId: string, seat: 0 | 1, characterId: string | null) => {
      setState((current) => {
        const target = current.campaigns.find((campaign) => campaign.id === campaignId);
        const previousCharacterId = target?.characterIds[seat] ?? null;

        const campaigns = current.campaigns.map((campaign) => {
          const cleanedSeats = campaign.characterIds.map((id) =>
            characterId && id === characterId ? null : id,
          ) as [string | null, string | null];

          if (campaign.id !== campaignId) {
            return { ...campaign, characterIds: cleanedSeats };
          }

          cleanedSeats[seat] = characterId;
          return { ...campaign, characterIds: cleanedSeats };
        });

        const linkedIds = new Set(
          campaigns.flatMap((campaign) =>
            campaign.characterIds.filter((id): id is string => Boolean(id)),
          ),
        );

        return {
          ...current,
          campaigns,
          characters: current.characters.map((character) => {
            if (linkedIds.has(character.id)) {
              const linkedCampaign = campaigns.find((campaign) =>
                campaign.characterIds.includes(character.id),
              );
              return {
                ...character,
                status: "linked",
                campaignId: linkedCampaign?.id ?? null,
              };
            }
            if (
              character.id === previousCharacterId ||
              character.id === characterId ||
              character.status === "linked"
            ) {
              return { ...character, status: "available", campaignId: null };
            }
            return character;
          }),
        };
      });
      announce(characterId ? "Personagem vinculado." : "Assento liberado.");
    },
    [announce],
  );

  const createCharacter = useCallback(
    (input: NewCharacterInput) => {
      const id = uniqueId("personagem");
      const resourceName = CLASS_RESOURCE[input.className];
      setState((current) => ({
        ...current,
        characters: [
          ...current.characters,
          {
            id,
            name: input.name.trim() || "Sem nome",
            player: input.player.trim() || "Jogador",
            pronouns: input.pronouns.trim() || "Não informado",
            className: input.className,
            origin: input.origin,
            level: 1,
            attributes: input.attributes,
            vitality: { current: 0, max: 0 },
            resource: { name: resourceName, current: 0, max: 0 },
            defense: 8 + input.attributes.Agilidade + input.attributes.Instinto,
            inventory: {
              used: 0,
              capacity: 5 + input.attributes.Força * 2,
              items: [],
            },
            specialties: input.specialties,
            abilities: [
              {
                id: uniqueId("ability"),
                name: "Habilidade de classe pendente",
                description:
                  "A tabela completa da classe ainda não foi anexada ao protótipo.",
              },
            ],
            conditions: [],
            appearance: input.appearance || "Não informado.",
            personality: input.personality || "Não informado.",
            objective: input.objective || "Não informado.",
            fear: input.fear || "Não informado.",
            initialBond: input.initialBond || "Não informado.",
            currentBond: input.currentBond || input.initialBond || "Não informado.",
            status: "available",
            campaignId: null,
            color: input.color,
            accent: input.accent,
            mechanicsPending: true,
          },
        ],
      }));
      announce("Personagem criado na biblioteca.");
      return id;
    },
    [announce],
  );

  const duplicateCharacter = useCallback(
    (characterId: string) => {
      setState((current) => {
        const source = current.characters.find((character) => character.id === characterId);
        if (!source) return current;
        return {
          ...current,
          characters: [
            ...current.characters,
            {
              ...source,
              id: uniqueId("personagem"),
              name: source.name + " · cópia",
              status: "available",
              campaignId: null,
              conditions: [],
              inventory: {
                ...source.inventory,
                items: source.inventory.items.map((item) => ({
                  ...item,
                  id: uniqueId("item"),
                })),
              },
            },
          ],
        };
      });
      announce("Cópia adicionada à biblioteca.");
    },
    [announce],
  );

  const archiveCharacter = useCallback(
    (characterId: string) => {
      setState((current) => ({
        ...current,
        characters: current.characters.map((character) =>
          character.id === characterId && character.status !== "linked"
            ? { ...character, status: "archived" }
            : character,
        ),
      }));
      announce("Personagem arquivado.");
    },
    [announce],
  );

  const adjustEnemyVitality = useCallback((enemyId: string, amount: number) => {
    setState((current) => ({
      ...current,
      enemies: current.enemies.map((enemy) =>
        enemy.id === enemyId
          ? {
              ...enemy,
              vitality: Math.max(
                0,
                Math.min(enemy.vitalityMax, enemy.vitality + amount),
              ),
            }
          : enemy,
      ),
      history: [
        {
          id: uniqueId("history"),
          time: now(),
          actor:
            current.enemies.find((enemy) => enemy.id === enemyId)?.name ?? "Inimigo",
          text: "Vitalidade alterada: " + (amount > 0 ? "+" : "") + amount,
        },
        ...current.history,
      ].slice(0, 30),
    }));
  }, []);

  const resetDemo = useCallback(() => {
    clearDemoState();
    setState(INITIAL_STATE);
    announce("Demonstração restaurada.");
  }, [announce]);

  const value = useMemo<RelicarioContextValue>(
    () => ({
      state,
      hydrated,
      notice,
      dismissNotice,
      announce,
      adjustVitality,
      adjustResource,
      addCondition,
      removeCondition,
      rollD20,
      createCampaign,
      setActiveCampaign,
      linkCharacter,
      createCharacter,
      duplicateCharacter,
      archiveCharacter,
      adjustEnemyVitality,
      resetDemo,
    }),
    [
      state,
      hydrated,
      notice,
      dismissNotice,
      announce,
      adjustVitality,
      adjustResource,
      addCondition,
      removeCondition,
      rollD20,
      createCampaign,
      setActiveCampaign,
      linkCharacter,
      createCharacter,
      duplicateCharacter,
      archiveCharacter,
      adjustEnemyVitality,
      resetDemo,
    ],
  );

  return (
    <RelicarioContext.Provider value={value}>
      {children}
      {notice ? (
        <button
          className="toast"
          type="button"
          onClick={dismissNotice}
          aria-label="Fechar aviso"
        >
          <span className="toast-mark" />
          {notice}
        </button>
      ) : null}
    </RelicarioContext.Provider>
  );
}

export function useRelicario() {
  const context = useContext(RelicarioContext);
  if (!context) {
    throw new Error("useRelicario must be used within RelicarioProvider");
  }
  return context;
}
