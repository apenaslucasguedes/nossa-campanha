import type { Campaign, Character } from "@/types/relicario";
import { ATTRIBUTES } from "@/data/relicario";

const list = (items: string[]) =>
  items.length ? items.map((item) => "- " + item).join("\n") : "- Nenhum registro";

export function characterToMarkdown(character: Character): string {
  const attributes = ATTRIBUTES.map(
    (attribute) => "- " + attribute + ": " + character.attributes[attribute],
  ).join("\n");

  const inventory = character.inventory.items.length
    ? character.inventory.items
        .map((item) => "- " + item.name + " ×" + item.quantity)
        .join("\n")
    : "- Vazio";

  const abilities = character.abilities.length
    ? character.abilities
        .map((ability) => "- " + ability.name + ": " + ability.description)
        .join("\n")
    : "- Nenhuma habilidade registrada";

  return [
    "# " + character.name,
    "",
    "- Jogador: " + character.player,
    "- Classe: " + character.className,
    "- Origem: " + character.origin,
    "- Nível: " + character.level,
    "- Vitalidade: " + character.vitality.current + "/" + character.vitality.max,
    "- " +
      character.resource.name +
      ": " +
      character.resource.current +
      "/" +
      character.resource.max,
    "- Defesa: " + character.defense,
    "",
    "## Atributos",
    attributes,
    "",
    "## Especialidades",
    list(character.specialties),
    "",
    "## Inventário",
    inventory,
    "",
    "## Habilidades",
    abilities,
    "",
    "## Condições",
    list(character.conditions),
    "",
    "## História",
    "- Aparência: " + character.appearance,
    "- Personalidade: " + character.personality,
    "- Objetivo: " + character.objective,
    "- Medo: " + character.fear,
    "- Vínculo inicial: " + character.initialBond,
    "- Vínculo atual: " + character.currentBond,
  ].join("\n");
}

export function campaignToMarkdown(
  campaign: Campaign,
  characters: Character[],
): string {
  const seats = campaign.characterIds.map((characterId, index) => {
    const character = characters.find((item) => item.id === characterId);
    return (
      "### Assento " +
      (index + 1) +
      "\n" +
      (character
        ? "- " +
          character.name +
          " · " +
          character.className +
          " · Nível " +
          character.level +
          "\n- Vitalidade: " +
          character.vitality.current +
          "/" +
          character.vitality.max +
          "\n- " +
          character.resource.name +
          ": " +
          character.resource.current +
          "/" +
          character.resource.max +
          "\n- Defesa: " +
          character.defense
        : "- Vazio")
    );
  });

  return [
    "# Campanha: " + campaign.name,
    "",
    "- Status: " + (campaign.status === "active" ? "Ativa" : "Pausada"),
    "- Região inicial: " + campaign.region,
    "- Referência do chat: " + (campaign.chatReference || "Não informada"),
    "",
    "## Resumo",
    campaign.summary,
    "",
    "## Personagens",
    seats.join("\n\n"),
    "",
    "## Locais revelados",
    list(campaign.revealedLocations),
    "",
    "## Missões provisórias",
    list(campaign.provisionalMissions),
    "",
    "## Estado mecânico",
    "Este pacote registra somente estado e regras. A condução permanece com o GPT Mestre.",
  ].join("\n");
}

export function downloadMarkdown(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
