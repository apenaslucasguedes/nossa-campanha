import type { Metadata } from "next";
import "./globals.css";
import { RelicarioProvider } from "@/app/providers";
import { AppShell } from "@/components/app-shell";

export const metadata: Metadata = {
  title: "Relicário · RPG cooperativo",
  description:
    "Campanhas, personagens e estado mecânico de Auren para dois jogadores.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body>
        <RelicarioProvider>
          <AppShell>{children}</AppShell>
        </RelicarioProvider>
      </body>
    </html>
  );
}
