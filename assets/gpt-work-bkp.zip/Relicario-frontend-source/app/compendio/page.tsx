import { CompendiumScreen } from "@/components/screens/compendium-screen";

export default function CompendiumPage() {
  return <CompendiumScreen />;
}
