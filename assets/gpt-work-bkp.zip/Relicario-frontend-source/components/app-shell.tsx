"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { LogoAsset } from "@/components/assets";
import { SystemIcon } from "@/components/system-icon";
import { useRelicario } from "@/app/providers";

const navigation = [
  { href: "/campanhas", label: "Campanhas", icon: "campaigns" },
  { href: "/personagens", label: "Personagens", icon: "characters" },
  { href: "/mapa", label: "Mapa", icon: "map" },
  { href: "/mesa", label: "Mesa", icon: "table" },
  { href: "/compendio", label: "Compêndio", icon: "compendium" },
  { href: "/configuracoes", label: "Ajustes", icon: "settings" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { state } = useRelicario();
  const activeCampaign = state.campaigns.find(
    (campaign) => campaign.id === state.activeCampaignId,
  );

  const isActive = (href: string) => {
    if (href === "/campanhas") return pathname.startsWith("/campanha");
    if (href === "/personagens") {
      return pathname.startsWith("/personagem") || pathname === "/criar-personagem";
    }
    return pathname.startsWith(href);
  };

  return (
    <div className="app-frame">
      <aside className="sidebar">
        <Link href="/campanhas" className="brand-link" aria-label="Relicário, campanhas">
          <LogoAsset />
        </Link>

        <nav className="desktop-nav" aria-label="Navegação principal">
          {navigation.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={isActive(item.href) ? "nav-link active" : "nav-link"}
            >
              <span className="nav-mark">
                <SystemIcon name={item.icon} size={22} />
              </span>
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="sidebar-campaign">
          <span>Campanha ativa</span>
          <strong>{activeCampaign?.name ?? "Nenhuma"}</strong>
          <small>{activeCampaign?.region ?? "Escolha uma campanha"}</small>
          {activeCampaign ? (
            <Link href={"/campanha/" + activeCampaign.id}>Abrir registro</Link>
          ) : null}
        </div>

        <p className="sidebar-foot">Estado mecânico para dois jogadores.</p>
      </aside>

      <div className="main-column">
        <header className="mobile-header">
          <Link href="/campanhas" className="mobile-brand">
            Relicário
          </Link>
          <span>{activeCampaign?.name ?? "Sem campanha ativa"}</span>
        </header>
        <main className="content">{children}</main>
      </div>

      <nav className="mobile-nav" aria-label="Navegação móvel">
        {navigation.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={isActive(item.href) ? "mobile-nav-link active" : "mobile-nav-link"}
          >
            <span className="mobile-nav-icon">
              <SystemIcon name={item.icon} size={20} />
            </span>
            <small>{item.label}</small>
          </Link>
        ))}
      </nav>
    </div>
  );
}
