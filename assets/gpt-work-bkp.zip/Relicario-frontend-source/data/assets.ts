export const ASSETS = {
  icons: {
    campaigns: "/assets/icons/interface/campaigns.svg",
    characters: "/assets/icons/interface/characters.svg",
    map: "/assets/icons/interface/map.svg",
    compendium: "/assets/icons/interface/compendium.svg",
    settings: "/assets/icons/interface/settings.svg",
    sheet: "/assets/icons/interface/sheet.svg",
    inventory: "/assets/icons/interface/inventory.svg",
    abilities: "/assets/icons/interface/abilities.svg",
    history: "/assets/icons/interface/history.svg",
    revealedLocation: "/assets/icons/interface/revealed-location.svg",
    mission: "/assets/icons/interface/mission.svg",
    exportPackage: "/assets/icons/interface/export-package.svg",
    avatarFallback: "/assets/icons/interface/avatar-fallback.svg",
  },
  approvedSheets: {
    classesAndAttributes:
      "/assets/reference/classes-attributes-approved.png",
  },
} as const;

export type IconName = keyof typeof ASSETS.icons | "table";
