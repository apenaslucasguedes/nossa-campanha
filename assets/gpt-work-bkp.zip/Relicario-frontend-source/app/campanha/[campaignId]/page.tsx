import { CampaignScreen } from "@/components/screens/campaign-screen";

export default async function CampaignPage({
  params,
}: {
  params: Promise<{ campaignId: string }>;
}) {
  const { campaignId } = await params;
  return <CampaignScreen campaignId={campaignId} />;
}
