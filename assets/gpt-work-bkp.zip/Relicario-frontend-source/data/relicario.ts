import type {
  AttributeName,
  Campaign,
  Character,
  CharacterClass,
  ClassResource,
  Condition,
  DemoState,
  Region,
} from "@/types/relicario";

export const ATTRIBUTES: AttributeName[] = [
  "Força",
  "Agilidade",
  "Intelecto",
  "Presença",
  "Instinto",
];

export const CLASSES: Array<{
  name: CharacterClass;
  resource: ClassResource;
  accent: string;
}> = [
  { name: "Guerreiro", resource: "Vigor", accent: "#a74e3f" },
  { name: "Arcanista", resource: "Foco", accent: "#526f91" },
  { name: "Lâmina Sombria", resource: "Ímpeto", accent: "#78617e" },
  { name: "Necromante", resource: "Essência", accent: "#6f7e63" },
  { name: "Bardo", resource: "Inspiração", accent: "#b17a4a" },
  { name: "Druida", resource: "Seiva", accent: "#657a4e" },
];

export const CLASS_RESOURCE: Record<CharacterClass, ClassResource> = {
  Guerreiro: "Vigor",
  Arcanista: "Foco",
  "Lâmina Sombria": "Ímpeto",
  Necromante: "Essência",
  Bardo: "Inspiração",
  Druida: "Seiva",
};

export const SPECIALTIES = [
  "Atletismo",
  "Acrobacia",
  "Furtividade",
  "Investigação",
  "Percepção",
  "Sobrevivência",
  "Medicina",
  "Persuasão",
  "Intimidação",
  "História",
  "Arcanismo",
  "Performance",
  "Rastreamento",
  "Alquimia",
] as const;

export const CONDITIONS: Condition[] = [
  "Ferido",
  "Exausto",
  "Amedrontado",
  "Envenenado",
  "Imobilizado",
  "Desorientado",
  "Corrompido",
];

export const REGIONS: Region[] = [
  { name: "Estepes do Norte", metropolis: "Orvak", x: 45, y: 12, tone: "Gelo" },
  { name: "Cordilheira de Ferro", metropolis: "Kar-Dhor", x: 48, y: 31, tone: "Ferro" },
  { name: "Costa Quebrada", metropolis: "Serath", x: 17, y: 39, tone: "Costa" },
  { name: "Vale de Ardan", metropolis: "Vallora", x: 43, y: 50, tone: "Vale" },
  { name: "Floresta de Nhalor", metropolis: "Lethra", x: 68, y: 45, tone: "Mata" },
  { name: "Pântanos de Varg", metropolis: "Vel-Mara", x: 25, y: 69, tone: "Varg" },
  { name: "Deserto de Sal", metropolis: "Azhar", x: 67, y: 67, tone: "Sal" },
  { name: "Mar de Cinzas", metropolis: "Cineris", x: 47, y: 83, tone: "Cinza" },
  { name: "Península da Aurora", metropolis: "Elyria", x: 88, y: 47, tone: "Aurora" },
];

export const MARITIME_TERRITORIES = [
  "Arquipélago de Vesper",
  "Ilhas Cinzentas",
  "Ormara",
] as const;

const characters: Character[] = [
  {
    id: "aira",
    name: "Aira",
    player: "Lucas",
    pronouns: "ela/dela",
    className: "Arcanista",
    origin: "Vale de Ardan",
    level: 1,
    attributes: {
      Força: 0,
      Agilidade: 1,
      Intelecto: 3,
      Presença: 1,
      Instinto: 2,
    },
    vitality: { current: 10, max: 10 },
    resource: { name: "Foco", current: 8, max: 8 },
    defense: 11,
    inventory: {
      used: 3,
      capacity: 5,
      items: [
        { id: "aira-item-1", name: "Foco ritual", quantity: 1 },
        { id: "aira-item-2", name: "Caderno de campo", quantity: 1 },
        { id: "aira-item-3", name: "Provisões", quantity: 1 },
      ],
    },
    specialties: ["Arcanismo", "Investigação", "Percepção"],
    abilities: [
      {
        id: "aira-ability-1",
        name: "Habilidade de classe I",
        description: "Descrição mecânica reservada para o documento completo da classe.",
      },
      {
        id: "aira-ability-2",
        name: "Habilidade de classe II",
        description: "Descrição mecânica reservada para o documento completo da classe.",
      },
    ],
    conditions: [],
    appearance: "Manto azul-mineral, cabelo curto e marcas de viagem nas luvas.",
    personality: "Observadora, direta e cuidadosa ao registrar descobertas.",
    objective: "Compreender o sinal encontrado no Vale de Ardan.",
    fear: "Perder o controle do próprio Foco.",
    initialBond: "Toren protegeu Aira durante a primeira travessia.",
    currentBond: "A confiança cresce quando os dois dividem decisões difíceis.",
    status: "linked",
    campaignId: "cinzas-de-ardan",
    color: "#26333e",
    accent: "#6c8cab",
  },
  {
    id: "toren",
    name: "Toren",
    player: "Matheus",
    pronouns: "ele/dele",
    className: "Guerreiro",
    origin: "Cordilheira de Ferro",
    level: 1,
    attributes: {
      Força: 3,
      Agilidade: 1,
      Intelecto: 0,
      Presença: 1,
      Instinto: 2,
    },
    vitality: { current: 20, max: 20 },
    resource: { name: "Vigor", current: 6, max: 6 },
    defense: 11,
    inventory: {
      used: 6,
      capacity: 11,
      items: [
        { id: "toren-item-1", name: "Lâmina de viagem", quantity: 1 },
        { id: "toren-item-2", name: "Corda", quantity: 1 },
        { id: "toren-item-3", name: "Provisões", quantity: 2 },
        { id: "toren-item-4", name: "Ferramentas", quantity: 2 },
      ],
    },
    specialties: ["Atletismo", "Intimidação", "Sobrevivência"],
    abilities: [
      {
        id: "toren-ability-1",
        name: "Habilidade de classe I",
        description: "Descrição mecânica reservada para o documento completo da classe.",
      },
      {
        id: "toren-ability-2",
        name: "Habilidade de classe II",
        description: "Descrição mecânica reservada para o documento completo da classe.",
      },
    ],
    conditions: ["Ferido"],
    appearance: "Armadura escura de viagem, tecido oxidado e postura firme.",
    personality: "Prático, atento ao terreno e econômico nas palavras.",
    objective: "Garantir que os dois atravessem a Cordilheira em segurança.",
    fear: "Falhar quando Aira depender dele.",
    initialBond: "Aira conhece a razão que o fez deixar Kar-Dhor.",
    currentBond: "Toren passou a confiar nas leituras de Aira.",
    status: "linked",
    campaignId: "cinzas-de-ardan",
    color: "#3b2c28",
    accent: "#a35c48",
  },
  {
    id: "sira",
    name: "Sira",
    player: "Lucas",
    pronouns: "elu/delu",
    className: "Bardo",
    origin: "Costa Quebrada",
    level: 1,
    attributes: {
      Força: 1,
      Agilidade: 2,
      Intelecto: 1,
      Presença: 3,
      Instinto: 0,
    },
    vitality: { current: 0, max: 0 },
    resource: { name: "Inspiração", current: 0, max: 0 },
    defense: 10,
    inventory: {
      used: 2,
      capacity: 7,
      items: [
        { id: "sira-item-1", name: "Instrumento de mão", quantity: 1 },
        { id: "sira-item-2", name: "Caderno", quantity: 1 },
      ],
    },
    specialties: ["Performance", "Persuasão"],
    abilities: [
      {
        id: "sira-ability-1",
        name: "Habilidade de classe pendente",
        description: "A tabela completa da classe ainda não foi anexada ao protótipo.",
      },
    ],
    conditions: [],
    appearance: "Camadas de tecido escuro com detalhes em cobre envelhecido.",
    personality: "Atenta ao ritmo das conversas e aos sinais do ambiente.",
    objective: "Registrar caminhos e encontros de Auren.",
    fear: "Ser impedida de seguir viagem.",
    initialBond: "Ainda não definido.",
    currentBond: "Ainda não definido.",
    status: "available",
    campaignId: null,
    color: "#403128",
    accent: "#b17a4a",
    mechanicsPending: true,
  },
];

const campaigns: Campaign[] = [
  {
    id: "cinzas-de-ardan",
    name: "Cinzas sobre Ardan",
    status: "active",
    region: "Vale de Ardan",
    characterIds: ["aira", "toren"],
    summary: "Registro de campanha em andamento para dois jogadores.",
    revealedLocations: ["Vallora", "Passagem de Ferro", "Marco do Vale"],
    provisionalMissions: [
      "Verificar o marco encontrado na estrada.",
      "Registrar a próxima passagem segura.",
    ],
    chatReference: "GPT Mestre · conversa iniciada em 10 jul 2026",
  },
  {
    id: "farol-de-vesper",
    name: "Farol de Vesper",
    status: "paused",
    region: "Costa Quebrada",
    characterIds: [null, null],
    summary: "Campanha pausada, ainda sem dupla vinculada.",
    revealedLocations: ["Serath"],
    provisionalMissions: ["Definir a dupla antes de retomar."],
    chatReference: "",
  },
];

export const INITIAL_STATE: DemoState = {
  characters,
  campaigns,
  activeCampaignId: "cinzas-de-ardan",
  revealedPointIds: ["Vallora", "Kar-Dhor", "Serath", "Marco do Vale"],
  history: [
    {
      id: "history-1",
      time: "14:32",
      actor: "Aira",
      text: "Teste de Intelecto + Arcanismo",
      roll: 16,
    },
    {
      id: "history-2",
      time: "14:29",
      actor: "Toren",
      text: "Condição registrada: Ferido",
    },
    {
      id: "history-3",
      time: "14:25",
      actor: "Mesa",
      text: "Iniciativa atualizada",
    },
  ],
  enemies: [
    {
      id: "enemy-1",
      name: "Inimigo marcado",
      vitality: 7,
      vitalityMax: 12,
      zone: "Perto",
      conditions: ["Desorientado"],
    },
    {
      id: "enemy-2",
      name: "Inimigo distante",
      vitality: 9,
      vitalityMax: 9,
      zone: "Distante",
      conditions: [],
    },
  ],
};
