"use client";

import Link from "next/link";
import { useState } from "react";
import { ATTRIBUTES } from "@/data/relicario";
import { characterToMarkdown, downloadMarkdown } from "@/lib/markdown";
import { useRelicario } from "@/app/providers";
import { AvatarAsset, AssetNotice } from "@/components/assets";
import { SystemIcon } from "@/components/system-icon";
import {
  CharacterStatusTag,
  ConditionEditor,
  StatControl,
} from "@/components/character-parts";
import { Button, EmptyMessage, Meter, SectionCard } from "@/components/ui";

type CharacterTab = "Ficha" | "Inventário" | "Habilidades" | "História";

const characterTabs: Array<{
  label: CharacterTab;
  icon: "sheet" | "inventory" | "abilities" | "history";
}> = [
  { label: "Ficha", icon: "sheet" },
  { label: "Inventário", icon: "inventory" },
  { label: "Habilidades", icon: "abilities" },
  { label: "História", icon: "history" },
];

export function CharacterScreen({ characterId }: { characterId: string }) {
  const { state, hydrated, announce } = useRelicario();
  const [tab, setTab] = useState<CharacterTab>("Ficha");

  if (!hydrated) {
    return (
      <SectionCard title="Carregando ficha">
        <p className="muted">Recuperando o personagem deste dispositivo.</p>
      </SectionCard>
    );
  }

  const character = state.characters.find((item) => item.id === characterId);

  if (!character) {
    return (
      <SectionCard title="Personagem não encontrado">
        <EmptyMessage title="Ficha indisponível">
          O endereço não corresponde a um personagem salvo neste dispositivo.
        </EmptyMessage>
        <Link className="button button-primary" href="/personagens">
          Voltar à biblioteca
        </Link>
      </SectionCard>
    );
  }

  const campaign = state.campaigns.find((item) => item.id === character.campaignId);

  const exportSheet = () => {
    downloadMarkdown(character.id + ".md", characterToMarkdown(character));
    announce("Ficha exportada como Markdown.");
  };

  return (
    <>
      <div className="breadcrumb">
        <Link href="/personagens">Personagens</Link>
        <span>/</span>
        <span>{character.name}</span>
      </div>

      <section className="character-hero">
        <div className="character-portrait-wrap">
          <AvatarAsset
            name={character.name}
            className={character.className}
            color={character.color}
            accent={character.accent}
            size="hero"
          />
          <AssetNotice type="avatares" />
        </div>
        <div className="character-hero-copy">
          <div className="tag-row">
            <CharacterStatusTag character={character} />
            <span>Nível {character.level}</span>
            <span>{character.origin}</span>
          </div>
          <h1>{character.name}</h1>
          <p>
            {character.className} · {character.player} · {character.pronouns}
          </p>
          {campaign ? (
            <Link className="text-link" href={"/campanha/" + campaign.id}>
              {campaign.name}
            </Link>
          ) : (
            <span className="muted">Sem campanha vinculada</span>
          )}
        </div>
        <div className="character-hero-actions">
          <Button onClick={exportSheet}>Exportar Markdown</Button>
        </div>
      </section>

      <nav className="sheet-tabs" aria-label="Seções da ficha">
        {characterTabs.map(
          (item) => (
            <button
              key={item.label}
              type="button"
              className={tab === item.label ? "sheet-tab active" : "sheet-tab"}
              onClick={() => setTab(item.label)}
            >
              <SystemIcon name={item.icon} size={22} />
              <span>{item.label}</span>
            </button>
          ),
        )}
      </nav>

      {tab === "Ficha" ? (
        <div className="sheet-layout">
          <div className="sheet-main">
            <SectionCard eyebrow="Estado atual" title="Recursos">
              <div className="stat-control-grid">
                <StatControl character={character} type="vitality" />
                <StatControl character={character} type="resource" />
              </div>
              {character.mechanicsPending ? (
                <p className="mechanics-note">
                  A especificação não inclui as bases desta classe. Defesa e capacidade
                  de inventário já usam as fórmulas aprovadas.
                </p>
              ) : null}
            </SectionCard>

            <SectionCard eyebrow="Sistema próprio" title="Cinco atributos">
              <div className="attribute-grid">
                {ATTRIBUTES.map((attribute) => (
                  <div className="attribute-cell" key={attribute}>
                    <span>{attribute}</span>
                    <strong>{character.attributes[attribute]}</strong>
                  </div>
                ))}
              </div>
              <p className="formula-note">
                Teste: 1d20 + atributo + especialidade
              </p>
            </SectionCard>

            <SectionCard eyebrow="Treinamento" title="Especialidades">
              <div className="specialty-list">
                {character.specialties.map((specialty) => (
                  <span key={specialty}>{specialty}</span>
                ))}
              </div>
            </SectionCard>
          </div>

          <aside className="sheet-side">
            <SectionCard eyebrow="Valores derivados" title="Defesa e carga">
              <div className="derived-list">
                <div>
                  <span>Defesa</span>
                  <strong>{character.defense}</strong>
                  <small>8 + Agilidade + Instinto</small>
                </div>
                <div>
                  <span>Inventário</span>
                  <strong>
                    {character.inventory.used}/{character.inventory.capacity}
                  </strong>
                  <small>5 + Força × 2</small>
                </div>
              </div>
              <Meter
                current={character.inventory.used}
                max={character.inventory.capacity}
                tone="neutral"
              />
            </SectionCard>

            <SectionCard eyebrow="Estado" title="Condições">
              <ConditionEditor character={character} />
            </SectionCard>
          </aside>
        </div>
      ) : null}

      {tab === "Inventário" ? (
        <SectionCard
          eyebrow="Carga"
          title={
            "Inventário · " +
            character.inventory.used +
            "/" +
            character.inventory.capacity
          }
        >
          <div className="inventory-list">
            {character.inventory.items.length ? (
              character.inventory.items.map((item) => (
                <article key={item.id}>
                  <span className="inventory-mark">◆</span>
                  <div>
                    <strong>{item.name}</strong>
                    <small>{item.note || "Sem observação"}</small>
                  </div>
                  <b>×{item.quantity}</b>
                </article>
              ))
            ) : (
              <EmptyMessage title="Inventário vazio">
                A ficha está pronta para receber itens.
              </EmptyMessage>
            )}
          </div>
        </SectionCard>
      ) : null}

      {tab === "Habilidades" ? (
        <SectionCard eyebrow={character.className} title="Habilidades">
          <div className="ability-list">
            {character.abilities.map((ability, index) => (
              <article key={ability.id}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div>
                  <h3>{ability.name}</h3>
                  <p>{ability.description}</p>
                </div>
              </article>
            ))}
          </div>
        </SectionCard>
      ) : null}

      {tab === "História" ? (
        <div className="narrative-grid">
          {[
            ["Aparência", character.appearance],
            ["Personalidade", character.personality],
            ["Objetivo", character.objective],
            ["Medo", character.fear],
            ["Vínculo inicial", character.initialBond],
            ["Vínculo atual", character.currentBond],
          ].map(([title, text]) => (
            <SectionCard key={title} eyebrow="Registro narrativo" title={title}>
              <p className="narrative-text">{text}</p>
            </SectionCard>
          ))}
        </div>
      ) : null}
    </>
  );
}
