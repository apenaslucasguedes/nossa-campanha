"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import {
  ATTRIBUTES,
  CLASSES,
  REGIONS,
  SPECIALTIES,
} from "@/data/relicario";
import { useRelicario } from "@/app/providers";
import { AvatarAsset } from "@/components/assets";
import { Button, PageHeader, SectionCard, StatusTag } from "@/components/ui";
import type {
  AttributeName,
  NewCharacterInput,
} from "@/types/relicario";

const steps = [
  "Classe",
  "Atributos",
  "Identidade",
  "Vínculo",
  "Especialidades",
  "Visual",
  "Revisão",
] as const;

const initialForm: NewCharacterInput = {
  name: "",
  player: "",
  pronouns: "",
  className: "Guerreiro",
  origin: "Vale de Ardan",
  attributes: {
    Força: 3,
    Agilidade: 2,
    Intelecto: 1,
    Presença: 1,
    Instinto: 0,
  },
  specialties: [],
  appearance: "",
  personality: "",
  objective: "",
  fear: "",
  initialBond: "",
  currentBond: "",
  color: "#302b27",
  accent: "#9b7043",
};

export function CreateCharacterScreen() {
  const router = useRouter();
  const { createCharacter, announce } = useRelicario();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<NewCharacterInput>(initialForm);

  const classInfo = CLASSES.find((item) => item.name === form.className)!;
  const distributionValid = useMemo(
    () =>
      Object.values(form.attributes)
        .slice()
        .sort((a, b) => a - b)
        .join(",") === "0,1,1,2,3",
    [form.attributes],
  );

  const update = <K extends keyof NewCharacterInput>(
    key: K,
    value: NewCharacterInput[K],
  ) => setForm((current) => ({ ...current, [key]: value }));

  const updateAttribute = (attribute: AttributeName, value: number) => {
    setForm((current) => ({
      ...current,
      attributes: { ...current.attributes, [attribute]: value },
    }));
  };

  const toggleSpecialty = (specialty: string) => {
    setForm((current) => ({
      ...current,
      specialties: current.specialties.includes(specialty)
        ? current.specialties.filter((item) => item !== specialty)
        : [...current.specialties, specialty],
    }));
  };

  const canAdvance = () => {
    if (step === 1 && !distributionValid) return false;
    if (step === 2 && (!form.name.trim() || !form.player.trim())) return false;
    return true;
  };

  const advance = () => {
    if (!canAdvance()) {
      announce(
        step === 1
          ? "Use exatamente a distribuição 3, 2, 1, 1 e 0."
          : "Preencha nome e jogador para avançar.",
      );
      return;
    }
    setStep((current) => Math.min(6, current + 1));
  };

  const finish = () => {
    const id = createCharacter(form);
    router.push("/personagem/" + id);
  };

  return (
    <>
      <PageHeader
        eyebrow="Criação de personagem"
        title={steps[step]}
        description="Fluxo em sete etapas para registrar somente as decisões aprovadas do sistema."
      />

      <ol className="creation-steps" aria-label="Etapas da criação">
        {steps.map((item, index) => (
          <li
            key={item}
            className={
              index === step ? "current" : index < step ? "complete" : "upcoming"
            }
          >
            <span>{index < step ? "✓" : index + 1}</span>
            <small>{item}</small>
          </li>
        ))}
      </ol>

      <SectionCard className="creation-card">
        {step === 0 ? (
          <div>
            <div className="creation-intro">
              <p className="eyebrow">Etapa 1 de 7</p>
              <h2>Escolha uma das seis classes</h2>
              <p>O recurso exibido pertence à própria classe.</p>
            </div>
            <div className="class-choice-grid">
              {CLASSES.map((item, index) => (
                <button
                  className={
                    form.className === item.name ? "class-choice selected" : "class-choice"
                  }
                  key={item.name}
                  type="button"
                  onClick={() => update("className", item.name)}
                  style={{ "--class-accent": item.accent } as React.CSSProperties}
                >
                  <span className="class-choice-index">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <strong>{item.name}</strong>
                  <small>Recurso: {item.resource}</small>
                  <span className="class-asset-note">avatar aprovado pendente</span>
                </button>
              ))}
            </div>
          </div>
        ) : null}

        {step === 1 ? (
          <div>
            <div className="creation-intro">
              <p className="eyebrow">Etapa 2 de 7</p>
              <h2>Distribua os cinco valores</h2>
              <p>Use uma vez 3, uma vez 2, duas vezes 1 e uma vez 0.</p>
            </div>
            <div className="attribute-assignment">
              {ATTRIBUTES.map((attribute) => (
                <label key={attribute}>
                  <span>{attribute}</span>
                  <select
                    value={form.attributes[attribute]}
                    onChange={(event) =>
                      updateAttribute(attribute, Number(event.target.value))
                    }
                  >
                    {[0, 1, 2, 3].map((value) => (
                      <option key={value} value={value}>
                        {value}
                      </option>
                    ))}
                  </select>
                </label>
              ))}
            </div>
            <div className="distribution-status">
              <StatusTag tone={distributionValid ? "active" : "danger"}>
                {distributionValid ? "Distribuição correta" : "Revise os valores"}
              </StatusTag>
              <span>
                Atual:{" "}
                {Object.values(form.attributes)
                  .slice()
                  .sort((a, b) => b - a)
                  .join(" · ")}
              </span>
            </div>
          </div>
        ) : null}

        {step === 2 ? (
          <div>
            <div className="creation-intro">
              <p className="eyebrow">Etapa 3 de 7</p>
              <h2>Identidade</h2>
              <p>Registre dados do jogador e campos narrativos do personagem.</p>
            </div>
            <div className="form-grid">
              <label>
                <span>Nome do personagem</span>
                <input
                  value={form.name}
                  onChange={(event) => update("name", event.target.value)}
                  placeholder="Nome"
                />
              </label>
              <label>
                <span>Jogador</span>
                <input
                  value={form.player}
                  onChange={(event) => update("player", event.target.value)}
                  placeholder="Quem joga"
                />
              </label>
              <label>
                <span>Pronomes ou apresentação</span>
                <input
                  value={form.pronouns}
                  onChange={(event) => update("pronouns", event.target.value)}
                  placeholder="Como se apresenta"
                />
              </label>
              <label>
                <span>Origem</span>
                <select
                  value={form.origin}
                  onChange={(event) => update("origin", event.target.value)}
                >
                  {REGIONS.map((region) => (
                    <option key={region.name}>{region.name}</option>
                  ))}
                </select>
              </label>
              <label className="field-wide">
                <span>Personalidade</span>
                <textarea
                  value={form.personality}
                  onChange={(event) => update("personality", event.target.value)}
                  placeholder="Traços que ajudam o jogador a interpretar"
                />
              </label>
              <label>
                <span>Objetivo</span>
                <textarea
                  value={form.objective}
                  onChange={(event) => update("objective", event.target.value)}
                  placeholder="O que busca"
                />
              </label>
              <label>
                <span>Medo</span>
                <textarea
                  value={form.fear}
                  onChange={(event) => update("fear", event.target.value)}
                  placeholder="O que evita"
                />
              </label>
            </div>
          </div>
        ) : null}

        {step === 3 ? (
          <div>
            <div className="creation-intro">
              <p className="eyebrow">Etapa 4 de 7</p>
              <h2>Vínculo</h2>
              <p>O vínculo registra a relação com o outro personagem da dupla.</p>
            </div>
            <div className="form-grid">
              <label className="field-wide">
                <span>Vínculo inicial</span>
                <textarea
                  value={form.initialBond}
                  onChange={(event) => update("initialBond", event.target.value)}
                  placeholder="Como a relação começa"
                />
              </label>
              <label className="field-wide">
                <span>Vínculo atual</span>
                <textarea
                  value={form.currentBond}
                  onChange={(event) => update("currentBond", event.target.value)}
                  placeholder="Como a relação está agora"
                />
              </label>
            </div>
          </div>
        ) : null}

        {step === 4 ? (
          <div>
            <div className="creation-intro">
              <p className="eyebrow">Etapa 5 de 7</p>
              <h2>Especialidades</h2>
              <p>Selecione as especialidades registradas na ficha.</p>
            </div>
            <div className="specialty-choice-grid">
              {SPECIALTIES.map((specialty) => (
                <label
                  key={specialty}
                  className={
                    form.specialties.includes(specialty)
                      ? "specialty-choice selected"
                      : "specialty-choice"
                  }
                >
                  <input
                    type="checkbox"
                    checked={form.specialties.includes(specialty)}
                    onChange={() => toggleSpecialty(specialty)}
                  />
                  <span>{specialty}</span>
                </label>
              ))}
            </div>
          </div>
        ) : null}

        {step === 5 ? (
          <div>
            <div className="creation-intro">
              <p className="eyebrow">Etapa 6 de 7</p>
              <h2>Visual</h2>
              <p>As cores serão aplicadas ao avatar aprovado quando o asset for inserido.</p>
            </div>
            <div className="visual-editor">
              <div className="visual-preview">
                <AvatarAsset
                  name={form.name || "P"}
                  className={form.className}
                  color={form.color}
                  accent={form.accent}
                  size="hero"
                />
                <strong>{form.name || "Personagem"}</strong>
                <span>{form.className}</span>
                <small>Avatar original pendente</small>
              </div>
              <div className="form-grid">
                <label>
                  <span>Cor base</span>
                  <input
                    type="color"
                    value={form.color}
                    onChange={(event) => update("color", event.target.value)}
                  />
                </label>
                <label>
                  <span>Cor de acento</span>
                  <input
                    type="color"
                    value={form.accent}
                    onChange={(event) => update("accent", event.target.value)}
                  />
                </label>
                <label className="field-wide">
                  <span>Aparência</span>
                  <textarea
                    value={form.appearance}
                    onChange={(event) => update("appearance", event.target.value)}
                    placeholder="Descrição visual"
                  />
                </label>
              </div>
            </div>
          </div>
        ) : null}

        {step === 6 ? (
          <div>
            <div className="creation-intro">
              <p className="eyebrow">Etapa 7 de 7</p>
              <h2>Revisão final</h2>
              <p>Confira o registro antes de adicionar o personagem à biblioteca.</p>
            </div>
            <div className="review-layout">
              <div className="review-identity">
                <AvatarAsset
                  name={form.name || "P"}
                  className={form.className}
                  color={form.color}
                  accent={form.accent}
                  size="hero"
                />
                <div>
                  <h3>{form.name || "Sem nome"}</h3>
                  <p>
                    {form.className} · {form.origin}
                  </p>
                  <span>{form.player || "Jogador não informado"}</span>
                </div>
              </div>
              <div className="review-facts">
                <div>
                  <span>Recurso</span>
                  <strong>{classInfo.resource}</strong>
                </div>
                <div>
                  <span>Defesa</span>
                  <strong>
                    {8 + form.attributes.Agilidade + form.attributes.Instinto}
                  </strong>
                </div>
                <div>
                  <span>Inventário</span>
                  <strong>{5 + form.attributes.Força * 2}</strong>
                </div>
                <div>
                  <span>Especialidades</span>
                  <strong>{form.specialties.length}</strong>
                </div>
              </div>
              <div className="review-attributes">
                {ATTRIBUTES.map((attribute) => (
                  <span key={attribute}>
                    {attribute} <b>{form.attributes[attribute]}</b>
                  </span>
                ))}
              </div>
              <p className="mechanics-note">
                As bases de Vitalidade e recurso das seis classes não constam no
                arquivo recebido. O personagem será criado com esses dois máximos
                pendentes, sem inventar valores.
              </p>
            </div>
          </div>
        ) : null}

        <footer className="creation-actions">
          <Button
            variant="ghost"
            onClick={() => (step === 0 ? router.push("/personagens") : setStep(step - 1))}
          >
            {step === 0 ? "Cancelar" : "Voltar"}
          </Button>
          <span>
            {step + 1} / {steps.length}
          </span>
          {step < 6 ? (
            <Button onClick={advance}>Avançar</Button>
          ) : (
            <Button onClick={finish}>Criar personagem</Button>
          )}
        </footer>
      </SectionCard>
    </>
  );
}
