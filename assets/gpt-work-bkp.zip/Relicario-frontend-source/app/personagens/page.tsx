import { CharactersScreen } from "@/components/screens/characters-screen";

export default function CharactersPage() {
  return <CharactersScreen />;
}
