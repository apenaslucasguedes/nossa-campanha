# Relicário, fonte visual do frontend

Projeto editável do protótipo Relicário. Esta exportação preserva as telas,
componentes, estilos, dados mockados, persistência local e assets da interface,
sem credenciais, dados de usuário ou configuração privada de hospedagem.

## Stack

- React 19 e TypeScript
- Vite 8
- Vinext para executar a estrutura de rotas no formato `app/`
- CSS global com tokens visuais próprios e utilitários Tailwind disponíveis
- `localStorage` para persistir a demonstração no navegador
- Sem backend, autenticação, Supabase ou chamadas externas

As fontes não dependem de CDN. A interface usa `Georgia / Times New Roman` nos
títulos e `Inter / system-ui / Segoe UI` na interface. Se Inter não estiver
instalada, o navegador usa a fonte do sistema.

## Estrutura principal

- `app/`: rotas e layout global
- `components/screens/`: implementação de cada tela
- `components/ui.tsx`: componentes reutilizáveis de interface
- `components/app-shell.tsx`: navegação lateral e móvel
- `components/character-parts.tsx`: blocos reutilizáveis de personagem
- `components/assets.tsx` e `components/system-icon.tsx`: integração de assets
- `data/`: conteúdo mockado e manifesto centralizado de assets
- `types/`: tipagem completa do domínio
- `lib/`: persistência local e exportação Markdown
- `public/assets/`: ícones e referências visuais usados pela interface
- `app/globals.css`: tokens, layout, responsividade e estilos dos componentes

### Rotas

- `/campanhas`
- `/campanha/[campaignId]`
- `/personagens`
- `/personagem/[characterId]`
- `/criar-personagem`
- `/mapa`
- `/mesa`
- `/compendio`
- `/configuracoes`

## Rodar localmente

Requer Node.js 22.13 ou superior.

```bash
npm install
npm run dev
```

Para validar uma versão de produção:

```bash
npm run typecheck
npm run lint
npm run build
npm run preview
```

## Transferir para outro projeto React + TypeScript + Vite

Este pacote usa Vinext somente para manter as rotas no formato em que foram
criadas no protótipo. Há duas formas de integração:

1. Manter Vinext: copie `app`, `components`, `data`, `lib`, `types`, `public` e
   os arquivos de configuração. É o caminho mais direto para preservar tudo.
2. Usar React Router: copie `components`, `data`, `lib`, `types`, `public` e
   `app/globals.css`; transforme cada `app/**/page.tsx` em uma entrada do seu
   roteador; substitua `next/link` por `Link` do roteador e `next/navigation`
   por `useNavigate`, `useLocation` e parâmetros equivalentes.

O estado global está em `app/providers.tsx`. Envolva o roteador com
`RelicarioProvider` e mantenha `AppShell` ao redor das páginas.

## Dependências do ChatGPT Sites

A experiência visual, as interações, o `localStorage` e as exportações Markdown
não dependem do ChatGPT Sites. Somente a publicação no domínio
`*.chatgpt.site`, o controle de acesso e o processo de deploy eram fornecidos
pela hospedagem.

Os arquivos privados do hosting, helpers de autenticação, banco de exemplo,
credenciais e variáveis do ambiente hospedado foram deliberadamente excluídos.

## Assets pendentes

Os ícones específicos da interface estão em `public/assets/icons/interface`.
A folha aprovada de classes e atributos está em `public/assets/reference`.
Logo, mapa ilustrado e os seis avatares definitivos ainda usam componentes de
fallback preparados para substituição por meio de `data/assets.ts`.
