import type { CharacterClass } from "@/types/relicario";
import { SystemIcon } from "@/components/system-icon";

export function LogoAsset() {
  return (
    <div className="logo-placeholder" data-asset-status="placeholder">
      <span className="logo-placeholder-mark">R</span>
      <span className="logo-placeholder-type">
        <strong>Relicário</strong>
        <small>logo original pendente</small>
      </span>
    </div>
  );
}

export function AvatarAsset({
  name,
  className,
  color,
  accent,
  size = "large",
}: {
  name: string;
  className: CharacterClass;
  color: string;
  accent: string;
  size?: "small" | "medium" | "large" | "hero";
}) {
  const iconSize = {
    small: 28,
    medium: 38,
    large: 52,
    hero: 92,
  }[size];

  return (
    <div
      className={"avatar-placeholder avatar-" + size}
      style={{ "--avatar-color": color, "--avatar-accent": accent } as React.CSSProperties}
      data-asset-status="placeholder"
      title={"Avatar aprovado de " + className + " pendente"}
    >
      <SystemIcon name="avatarFallback" size={iconSize} />
      <span className="sr-only">
        Avatar de {name} aguardando a ilustração aprovada de {className}
      </span>
    </div>
  );
}

export function AssetNotice({ type }: { type: "mapa" | "ícones" | "avatares" }) {
  const label = {
    mapa: "mapa · asset pendente",
    ícones: "ícones · assets pendentes",
    avatares: "avatar da classe · pendente",
  }[type];

  return (
    <span className="asset-notice" data-asset-status="placeholder">
      {label}
    </span>
  );
}
