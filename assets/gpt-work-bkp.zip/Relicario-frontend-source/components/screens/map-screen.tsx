"use client";

import { useState } from "react";
import { MARITIME_TERRITORIES, REGIONS } from "@/data/relicario";
import { useRelicario } from "@/app/providers";
import { AssetNotice } from "@/components/assets";
import { Button, PageHeader, SectionCard, StatusTag } from "@/components/ui";
import type { Region } from "@/types/relicario";

export function MapScreen() {
  const { state } = useRelicario();
  const [zoom, setZoom] = useState(1);
  const [showMetropolises, setShowMetropolises] = useState(true);
  const [showRevealed, setShowRevealed] = useState(true);
  const [showHidden, setShowHidden] = useState(false);
  const [selected, setSelected] = useState<Region>(REGIONS[3]);

  const activeCampaign = state.campaigns.find(
    (campaign) => campaign.id === state.activeCampaignId,
  );

  return (
    <>
      <PageHeader
        eyebrow="Mapa"
        title="Atlas de Auren"
        description="O continente inteiro permanece visível. Pontos menores alternam somente entre oculto e revelado."
        actions={
          <div className="zoom-control">
            <Button
              variant="secondary"
              aria-label="Diminuir zoom"
              onClick={() => setZoom((value) => Math.max(0.8, value - 0.2))}
            >
              −
            </Button>
            <span>{Math.round(zoom * 100)}%</span>
            <Button
              variant="secondary"
              aria-label="Aumentar zoom"
              onClick={() => setZoom((value) => Math.min(1.6, value + 0.2))}
            >
              +
            </Button>
          </div>
        }
      />

      <div className="map-layout">
        <SectionCard className="map-card">
          <div className="map-toolbar">
            <div className="map-filter-group">
              <label>
                <input
                  type="checkbox"
                  checked={showMetropolises}
                  onChange={(event) => setShowMetropolises(event.target.checked)}
                />
                Metrópoles
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={showRevealed}
                  onChange={(event) => setShowRevealed(event.target.checked)}
                />
                Revelados
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={showHidden}
                  onChange={(event) => setShowHidden(event.target.checked)}
                />
                Ocultos
              </label>
            </div>
            <AssetNotice type="mapa" />
          </div>

          <div className="map-viewport">
            <div
              className="map-placeholder"
              style={{ transform: "scale(" + zoom + ")" }}
              data-asset-status="placeholder"
            >
              <div className="map-continent-shape" />
              <div className="map-placeholder-label">
                <span>Área preparada para o mapa ilustrado</span>
                <small>camada interativa preservada</small>
              </div>
              {REGIONS.map((region, index) => (
                <button
                  key={region.name}
                  type="button"
                  className={
                    selected.name === region.name
                      ? "region-marker selected"
                      : "region-marker"
                  }
                  style={{ left: region.x + "%", top: region.y + "%" }}
                  onClick={() => setSelected(region)}
                >
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <strong>{region.name}</strong>
                  {showMetropolises ? <small>{region.metropolis}</small> : null}
                </button>
              ))}

              {showRevealed
                ? state.revealedPointIds
                    .filter(
                      (point) => !REGIONS.some((region) => region.metropolis === point),
                    )
                    .map((point, index) => (
                      <span
                        key={point}
                        className="map-point revealed"
                        style={{
                          left: 40 + index * 7 + "%",
                          top: 56 + index * 4 + "%",
                        }}
                        title={point}
                      >
                        <i />
                        {point}
                      </span>
                    ))
                : null}

              {showHidden ? (
                <>
                  <span className="map-point hidden" style={{ left: "58%", top: "58%" }}>
                    <i />
                    Oculto
                  </span>
                  <span className="map-point hidden" style={{ left: "32%", top: "48%" }}>
                    <i />
                    Oculto
                  </span>
                </>
              ) : null}
            </div>
          </div>
        </SectionCard>

        <aside className="map-side">
          <SectionCard eyebrow="Região selecionada" title={selected.name}>
            <div className="region-detail">
              <div>
                <span>Metrópole</span>
                <strong>{selected.metropolis}</strong>
              </div>
              <div>
                <span>Zona visual</span>
                <strong>{selected.tone}</strong>
              </div>
              <StatusTag
                tone={activeCampaign?.region === selected.name ? "active" : "neutral"}
              >
                {activeCampaign?.region === selected.name
                  ? "Região inicial ativa"
                  : "Região de Auren"}
              </StatusTag>
            </div>
          </SectionCard>

          <SectionCard eyebrow="Territórios marítimos" title="Além do continente">
            <ul className="record-list">
              {MARITIME_TERRITORIES.map((territory) => (
                <li key={territory}>
                  <span className="record-mark" />
                  {territory}
                </li>
              ))}
            </ul>
          </SectionCard>

          <SectionCard eyebrow="Campanha ativa" title={activeCampaign?.name ?? "Nenhuma"}>
            <p className="reference-text">
              {activeCampaign
                ? activeCampaign.revealedLocations.length +
                  " locais menores revelados no registro."
                : "Escolha uma campanha para ver o estado."}
            </p>
          </SectionCard>
        </aside>
      </div>
    </>
  );
}
