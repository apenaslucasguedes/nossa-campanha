import { ASSETS, type IconName } from "@/data/assets";

export function SystemIcon({
  name,
  size = 24,
  className = "",
}: {
  name: IconName;
  size?: number;
  className?: string;
}) {
  if (name === "table") {
    return (
      <span
        className={"system-icon approved-d20-crop " + className}
        style={{ "--icon-size": size + "px" } as React.CSSProperties}
        aria-hidden="true"
      >
        {/* Exact crop of the approved sheet, kept as an image to avoid redrawing it. */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={ASSETS.approvedSheets.classesAndAttributes} alt="" />
      </span>
    );
  }

  return (
    <span
      className={"system-icon " + className}
      style={
        {
          "--icon-size": size + "px",
          "--icon-mask": "url(" + ASSETS.icons[name] + ")",
        } as React.CSSProperties
      }
      aria-hidden="true"
    />
  );
}
