"use client";

import { useState } from "react";
import { CONDITIONS } from "@/data/relicario";
import { useRelicario } from "@/app/providers";
import { AvatarAsset } from "@/components/assets";
import { Button, Meter, StatusTag } from "@/components/ui";
import type { Character, Condition } from "@/types/relicario";

export function CharacterIdentity({
  character,
  size = "medium",
}: {
  character: Character;
  size?: "compact" | "medium" | "large";
}) {
  return (
    <div className={"character-identity character-identity-" + size}>
      <AvatarAsset
        name={character.name}
        className={character.className}
        color={character.color}
        accent={character.accent}
        size={size === "compact" ? "small" : size === "large" ? "hero" : "medium"}
      />
      <div>
        <strong>{character.name}</strong>
        <span>
          {character.className} · Nível {character.level}
        </span>
        <small>{character.player}</small>
      </div>
    </div>
  );
}

export function StatControl({
  character,
  type,
  compact = false,
}: {
  character: Character;
  type: "vitality" | "resource";
  compact?: boolean;
}) {
  const { adjustVitality, adjustResource } = useRelicario();
  const stat = type === "vitality" ? character.vitality : character.resource;
  const label = type === "vitality" ? "Vitalidade" : character.resource.name;
  const pending = character.mechanicsPending && stat.max === 0;
  const adjust = type === "vitality" ? adjustVitality : adjustResource;

  return (
    <div className={compact ? "stat-control stat-control-compact" : "stat-control"}>
      <div className="stat-control-head">
        <span>{label}</span>
        <strong>{pending ? "Pendente" : stat.current + " / " + stat.max}</strong>
      </div>
      <Meter
        current={stat.current}
        max={stat.max}
        tone={type === "vitality" ? "vitality" : "resource"}
      />
      <div className="stepper">
        <Button
          variant="ghost"
          aria-label={"Reduzir " + label}
          onClick={() => adjust(character.id, -1)}
          disabled={pending || stat.current <= 0}
        >
          −
        </Button>
        <span>{pending ? "base não anexada" : label}</span>
        <Button
          variant="ghost"
          aria-label={"Aumentar " + label}
          onClick={() => adjust(character.id, 1)}
          disabled={pending || stat.current >= stat.max}
        >
          +
        </Button>
      </div>
    </div>
  );
}

export function ConditionEditor({
  character,
  compact = false,
}: {
  character: Character;
  compact?: boolean;
}) {
  const { addCondition, removeCondition } = useRelicario();
  const [selected, setSelected] = useState<Condition>("Exausto");
  const available = CONDITIONS.filter(
    (condition) => !character.conditions.includes(condition),
  );

  return (
    <div className={compact ? "condition-editor compact" : "condition-editor"}>
      <div className="condition-list">
        {character.conditions.length ? (
          character.conditions.map((condition) => (
            <button
              key={condition}
              className="condition-chip"
              type="button"
              onClick={() => removeCondition(character.id, condition)}
              aria-label={"Remover condição " + condition}
            >
              {condition} <span>×</span>
            </button>
          ))
        ) : (
          <span className="muted">Sem condições</span>
        )}
      </div>
      {available.length ? (
        <div className="condition-add">
          <select
            value={available.includes(selected) ? selected : available[0]}
            onChange={(event) => setSelected(event.target.value as Condition)}
            aria-label="Escolher condição"
          >
            {available.map((condition) => (
              <option key={condition}>{condition}</option>
            ))}
          </select>
          <Button
            variant="secondary"
            onClick={() =>
              addCondition(
                character.id,
                available.includes(selected) ? selected : available[0],
              )
            }
          >
            Adicionar
          </Button>
        </div>
      ) : null}
    </div>
  );
}

export function MechanicalSummary({ character }: { character: Character }) {
  return (
    <div className="mechanical-summary">
      <div>
        <span>Vitalidade</span>
        <strong>
          {character.mechanicsPending && character.vitality.max === 0
            ? "Pendente"
            : character.vitality.current + "/" + character.vitality.max}
        </strong>
      </div>
      <div>
        <span>{character.resource.name}</span>
        <strong>
          {character.mechanicsPending && character.resource.max === 0
            ? "Pendente"
            : character.resource.current + "/" + character.resource.max}
        </strong>
      </div>
      <div>
        <span>Defesa</span>
        <strong>{character.defense}</strong>
      </div>
      <div>
        <span>Inventário</span>
        <strong>
          {character.inventory.used}/{character.inventory.capacity}
        </strong>
      </div>
    </div>
  );
}

export function CharacterStatusTag({ character }: { character: Character }) {
  if (character.status === "linked") {
    return <StatusTag tone="active">Vinculado</StatusTag>;
  }
  if (character.status === "archived") {
    return <StatusTag tone="paused">Arquivado</StatusTag>;
  }
  if (character.status === "retired") {
    return <StatusTag tone="neutral">Aposentado</StatusTag>;
  }
  return <StatusTag tone="moss">Disponível</StatusTag>;
}
