"use client";

import { useState } from "react";
import { useRelicario } from "@/app/providers";
import {
  CharacterIdentity,
  ConditionEditor,
  StatControl,
} from "@/components/character-parts";
import { Button, Meter, PageHeader, SectionCard, StatusTag } from "@/components/ui";

export function TableScreen() {
  const {
    state,
    rollD20,
    adjustEnemyVitality,
  } = useRelicario();
  const [lastRoll, setLastRoll] = useState<number | null>(null);
  const activeCampaign = state.campaigns.find(
    (campaign) => campaign.id === state.activeCampaignId,
  );
  const characters =
    activeCampaign?.characterIds
      .map((id) => state.characters.find((character) => character.id === id))
      .filter((character) => Boolean(character)) ?? [];

  const initiative = [
    characters[0]?.name,
    state.enemies[0]?.name,
    characters[1]?.name,
    state.enemies[1]?.name,
  ].filter(Boolean);

  const handleRoll = () => setLastRoll(rollD20("Mesa"));

  return (
    <>
      <PageHeader
        eyebrow="Mesa compartilhada"
        title={activeCampaign?.name ?? "Sem campanha ativa"}
        description="Estado mecânico da dupla, inimigos, zonas, iniciativa e histórico de ações."
        actions={
          <div className="die-action">
            <div className={lastRoll ? "d20-result rolled" : "d20-result"}>
              <small>d20</small>
              <strong>{lastRoll ?? "·"}</strong>
            </div>
            <Button onClick={handleRoll}>Rolar d20</Button>
          </div>
        }
      />

      <div className="table-layout">
        <div className="table-main">
          <div className="table-character-grid">
            {characters.map((character) =>
              character ? (
                <article className="table-character" key={character.id}>
                  <header>
                    <CharacterIdentity character={character} size="medium" />
                    <StatusTag tone="neutral">Defesa {character.defense}</StatusTag>
                  </header>
                  <div className="table-stat-grid">
                    <StatControl character={character} type="vitality" compact />
                    <StatControl character={character} type="resource" compact />
                  </div>
                  <ConditionEditor character={character} compact />
                </article>
              ) : null,
            )}
          </div>

          <SectionCard eyebrow="Oposição" title="Inimigos">
            <div className="enemy-list">
              {state.enemies.map((enemy) => (
                <article key={enemy.id}>
                  <div className="enemy-head">
                    <div>
                      <strong>{enemy.name}</strong>
                      <StatusTag tone="danger">{enemy.zone}</StatusTag>
                    </div>
                    <span>
                      {enemy.vitality}/{enemy.vitalityMax}
                    </span>
                  </div>
                  <Meter current={enemy.vitality} max={enemy.vitalityMax} tone="vitality" />
                  <div className="enemy-actions">
                    <div className="condition-list">
                      {enemy.conditions.length ? (
                        enemy.conditions.map((condition) => (
                          <span className="condition-chip static" key={condition}>
                            {condition}
                          </span>
                        ))
                      ) : (
                        <span className="muted">Sem condições</span>
                      )}
                    </div>
                    <div className="stepper enemy-stepper">
                      <Button
                        variant="ghost"
                        onClick={() => adjustEnemyVitality(enemy.id, -1)}
                        disabled={enemy.vitality <= 0}
                      >
                        −
                      </Button>
                      <span>Vitalidade</span>
                      <Button
                        variant="ghost"
                        onClick={() => adjustEnemyVitality(enemy.id, 1)}
                        disabled={enemy.vitality >= enemy.vitalityMax}
                      >
                        +
                      </Button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </SectionCard>

          <SectionCard eyebrow="Posicionamento" title="Zonas">
            <div className="zones">
              {["Corpo a corpo", "Perto", "Distante", "Fora de alcance"].map(
                (zone, index) => (
                  <div key={zone}>
                    <span>{index + 1}</span>
                    <strong>{zone}</strong>
                    <small>
                      {state.enemies.filter((enemy) => enemy.zone === zone).length} alvos
                    </small>
                  </div>
                ),
              )}
            </div>
            <p className="formula-note">Ataque e dano são resolvidos separadamente.</p>
          </SectionCard>
        </div>

        <aside className="table-side">
          <SectionCard eyebrow="Ordem atual" title="Iniciativa">
            <ol className="initiative-list">
              {initiative.map((name, index) => (
                <li key={String(name)}>
                  <span>{index + 1}</span>
                  <strong>{name}</strong>
                  {index === 0 ? <small>Agora</small> : null}
                </li>
              ))}
            </ol>
          </SectionCard>

          <SectionCard eyebrow="Registro mecânico" title="Histórico de ações">
            <div className="history-list">
              {state.history.slice(0, 10).map((record) => (
                <article key={record.id}>
                  <time>{record.time}</time>
                  <div>
                    <strong>{record.actor}</strong>
                    <span>{record.text}</span>
                  </div>
                  {record.roll ? <b>{record.roll}</b> : null}
                </article>
              ))}
            </div>
          </SectionCard>
        </aside>
      </div>
    </>
  );
}
