import type { ButtonHTMLAttributes, ReactNode } from "react";

export function Button({
  children,
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger";
}) {
  return (
    <button
      className={"button button-" + variant + " " + className}
      type="button"
      {...props}
    >
      {children}
    </button>
  );
}

export function StatusTag({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "active" | "paused" | "neutral" | "danger" | "mineral" | "moss";
}) {
  return <span className={"status-tag status-" + tone}>{children}</span>;
}

export function SectionCard({
  children,
  className = "",
  title,
  eyebrow,
  action,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  eyebrow?: string;
  action?: ReactNode;
}) {
  return (
    <section className={"section-card " + className}>
      {title || action ? (
        <header className="section-card-header">
          <div>
            {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
            {title ? <h2>{title}</h2> : null}
          </div>
          {action}
        </header>
      ) : null}
      {children}
    </section>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow: string;
  title: string;
  description: string;
  actions?: ReactNode;
}) {
  return (
    <header className="page-header">
      <div className="page-header-copy">
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {actions ? <div className="page-actions">{actions}</div> : null}
    </header>
  );
}

export function Meter({
  current,
  max,
  tone = "vitality",
}: {
  current: number;
  max: number;
  tone?: "vitality" | "resource" | "neutral";
}) {
  const progress = max > 0 ? Math.max(0, Math.min(100, (current / max) * 100)) : 0;
  return (
    <div
      className={"meter meter-" + tone}
      role="meter"
      aria-valuemin={0}
      aria-valuemax={max}
      aria-valuenow={current}
    >
      <span style={{ width: progress + "%" }} />
    </div>
  );
}

export function EmptyMessage({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="empty-message">
      <span className="empty-glyph">◇</span>
      <strong>{title}</strong>
      <p>{children}</p>
    </div>
  );
}
