"use client";

import Link from "next/link";
import { useState } from "react";
import { REGIONS } from "@/data/relicario";
import { campaignToMarkdown, downloadMarkdown } from "@/lib/markdown";
import { useRelicario } from "@/app/providers";
import { CharacterIdentity } from "@/components/character-parts";
import { SystemIcon } from "@/components/system-icon";
import { Button, EmptyMessage, PageHeader, SectionCard, StatusTag } from "@/components/ui";

export function CampaignsScreen() {
  const {
    state,
    createCampaign,
    setActiveCampaign,
    announce,
  } = useRelicario();
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [region, setRegion] = useState("Vale de Ardan");

  const handleCreate = () => {
    if (!name.trim()) {
      announce("Dê um nome para a campanha.");
      return;
    }
    createCampaign({ name, region });
    setName("");
    setCreating(false);
  };

  const exportForGpt = async (campaignId: string) => {
    const campaign = state.campaigns.find((item) => item.id === campaignId);
    if (!campaign) return;
    const markdown = campaignToMarkdown(campaign, state.characters);
    try {
      await navigator.clipboard.writeText(markdown);
      announce("Pacote Markdown copiado para o GPT Mestre.");
    } catch {
      downloadMarkdown(campaign.id + ".md", markdown);
      announce("Pacote Markdown exportado.");
    }
  };

  return (
    <>
      <PageHeader
        eyebrow="Campanhas"
        title="Registros em Auren"
        description="Organize o estado de cada campanha, vincule a dupla e prepare o pacote para o GPT Mestre."
        actions={
          <Button onClick={() => setCreating((value) => !value)}>
            {creating ? "Fechar criação" : "Criar campanha"}
          </Button>
        }
      />

      {creating ? (
        <SectionCard
          className="create-campaign-panel"
          eyebrow="Nova campanha"
          title="Preparar dois assentos"
        >
          <div className="form-grid form-grid-campaign">
            <label>
              <span>Nome</span>
              <input
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Nome da campanha"
                autoFocus
              />
            </label>
            <label>
              <span>Região inicial</span>
              <select value={region} onChange={(event) => setRegion(event.target.value)}>
                {REGIONS.map((item) => (
                  <option key={item.name} value={item.name}>
                    {item.name} · {item.metropolis}
                  </option>
                ))}
              </select>
            </label>
            <div className="form-actions">
              <Button variant="ghost" onClick={() => setCreating(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreate}>Criar registro</Button>
            </div>
          </div>
        </SectionCard>
      ) : null}

      <div className="campaign-list">
        {state.campaigns.map((campaign, index) => {
          const isActive = campaign.id === state.activeCampaignId;
          const linked = campaign.characterIds.map((id) =>
            state.characters.find((character) => character.id === id),
          );
          return (
            <article
              className={isActive ? "campaign-card campaign-card-active" : "campaign-card"}
              key={campaign.id}
            >
              <div className="campaign-index">{String(index + 1).padStart(2, "0")}</div>
              <div className="campaign-main">
                <div className="campaign-heading">
                  <div>
                    <div className="tag-row">
                      <StatusTag tone={campaign.status === "active" ? "active" : "paused"}>
                        {campaign.status === "active" ? "Ativa" : "Pausada"}
                      </StatusTag>
                      <span className="region-label">{campaign.region}</span>
                    </div>
                    <h2>{campaign.name}</h2>
                    <p>{campaign.summary}</p>
                  </div>
                  {!isActive ? (
                    <Button
                      variant="ghost"
                      onClick={() => setActiveCampaign(campaign.id)}
                    >
                      Tornar ativa
                    </Button>
                  ) : (
                    <span className="active-seal">Campanha atual</span>
                  )}
                </div>

                <div className="seat-grid">
                  {linked.map((character, seat) => (
                    <div className="seat" key={seat}>
                      <span className="seat-number">Assento {seat + 1}</span>
                      {character ? (
                        <CharacterIdentity character={character} size="compact" />
                      ) : (
                        <EmptyMessage title="Assento livre">
                          Vincule um personagem ao abrir a campanha.
                        </EmptyMessage>
                      )}
                    </div>
                  ))}
                </div>

                <footer className="campaign-footer">
                  <div className="campaign-facts">
                    <span>
                      <SystemIcon name="revealedLocation" size={18} />
                      {campaign.revealedLocations.length} locais revelados
                    </span>
                    <span>
                      <SystemIcon name="mission" size={18} />
                      {campaign.provisionalMissions.length} missões provisórias
                    </span>
                  </div>
                  <div className="button-row">
                    <Button variant="secondary" onClick={() => exportForGpt(campaign.id)}>
                      <SystemIcon name="exportPackage" size={18} />
                      Exportar para GPT
                    </Button>
                    <Link className="button button-primary" href={"/campanha/" + campaign.id}>
                      Abrir
                    </Link>
                  </div>
                </footer>
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}
