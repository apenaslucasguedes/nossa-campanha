import { CampaignsScreen } from "@/components/screens/campaigns-screen";

export default function CampaignsPage() {
  return <CampaignsScreen />;
}
