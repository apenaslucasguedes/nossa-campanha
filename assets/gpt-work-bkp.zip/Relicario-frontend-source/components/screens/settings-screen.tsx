"use client";

import { useRelicario } from "@/app/providers";
import { AssetNotice } from "@/components/assets";
import { Button, PageHeader, SectionCard, StatusTag } from "@/components/ui";

export function SettingsScreen() {
  const { resetDemo, hydrated } = useRelicario();

  return (
    <>
      <PageHeader
        eyebrow="Configurações"
        title="Demonstração local"
        description="Estado do protótipo, persistência neste dispositivo e pontos preparados para integração."
      />
      <div className="settings-grid">
        <SectionCard eyebrow="Persistência" title="Dados da demonstração">
          <div className="settings-row">
            <div>
              <strong>Armazenamento local</strong>
              <p>Campanhas, personagens e estado mecânico ficam neste navegador.</p>
            </div>
            <StatusTag tone={hydrated ? "active" : "paused"}>
              {hydrated ? "Ativo" : "Carregando"}
            </StatusTag>
          </div>
          <Button variant="danger" onClick={resetDemo}>
            Restaurar dados iniciais
          </Button>
        </SectionCard>

        <SectionCard eyebrow="Assets" title="Substituições preparadas">
          <div className="asset-status-list">
            <div>
              <span>Logo</span>
              <StatusTag tone="paused">Pendente</StatusTag>
            </div>
            <div>
              <AssetNotice type="mapa" />
              <StatusTag tone="paused">Pendente</StatusTag>
            </div>
            <div>
              <AssetNotice type="ícones" />
              <StatusTag tone="paused">Pendente</StatusTag>
            </div>
            <div>
              <AssetNotice type="avatares" />
              <StatusTag tone="paused">Pendente</StatusTag>
            </div>
          </div>
          <p className="mechanics-note">
            Os componentes mantêm dimensões e pontos de troca sem redesenhar os assets.
          </p>
        </SectionCard>

        <SectionCard eyebrow="Arquitetura" title="Pronto para dados reais">
          <ul className="record-list">
            <li>
              <span className="record-mark" />
              Tipos de campanha e personagem
            </li>
            <li>
              <span className="record-mark" />
              Camada de persistência isolada
            </li>
            <li>
              <span className="record-mark" />
              Exportadores Markdown
            </li>
            <li>
              <span className="record-mark" />
              Componentes de estado mecânico
            </li>
          </ul>
        </SectionCard>
      </div>
    </>
  );
}
