"use client";

import Link from "next/link";
import { useState } from "react";
import { characterToMarkdown, downloadMarkdown } from "@/lib/markdown";
import { useRelicario } from "@/app/providers";
import {
  CharacterIdentity,
  CharacterStatusTag,
  MechanicalSummary,
} from "@/components/character-parts";
import { Button, EmptyMessage, PageHeader } from "@/components/ui";

type Filter = "all" | "available" | "linked" | "archived";

export function CharactersScreen() {
  const {
    state,
    duplicateCharacter,
    archiveCharacter,
    announce,
  } = useRelicario();
  const [filter, setFilter] = useState<Filter>("all");

  const visible = state.characters.filter((character) => {
    if (filter === "all") return character.status !== "archived";
    return character.status === filter;
  });

  const exportCharacter = (characterId: string) => {
    const character = state.characters.find((item) => item.id === characterId);
    if (!character) return;
    downloadMarkdown(character.id + ".md", characterToMarkdown(character));
    announce("Ficha exportada como Markdown.");
  };

  return (
    <>
      <PageHeader
        eyebrow="Biblioteca"
        title="Personagens"
        description="Gerencie personagens disponíveis, vínculos de campanha e fichas exportáveis."
        actions={
          <Link className="button button-primary" href="/criar-personagem">
            Criar personagem
          </Link>
        }
      />

      <div className="filter-bar" role="group" aria-label="Filtrar personagens">
        {[
          ["all", "Biblioteca"],
          ["available", "Disponíveis"],
          ["linked", "Vinculados"],
          ["archived", "Arquivados"],
        ].map(([value, label]) => (
          <button
            key={value}
            type="button"
            className={filter === value ? "filter-button active" : "filter-button"}
            onClick={() => setFilter(value as Filter)}
          >
            {label}
          </button>
        ))}
      </div>

      {visible.length ? (
        <div className="character-library-grid">
          {visible.map((character) => {
            const campaign = state.campaigns.find(
              (item) => item.id === character.campaignId,
            );
            return (
              <article className="character-card" key={character.id}>
                <header className="character-card-header">
                  <CharacterIdentity character={character} size="medium" />
                  <CharacterStatusTag character={character} />
                </header>

                <div className="character-origin">
                  <span>Origem</span>
                  <strong>{character.origin}</strong>
                </div>

                <MechanicalSummary character={character} />

                <div className="character-campaign-line">
                  <span>Campanha</span>
                  {campaign ? (
                    <Link href={"/campanha/" + campaign.id}>{campaign.name}</Link>
                  ) : (
                    <strong>Nenhuma</strong>
                  )}
                </div>

                {character.mechanicsPending ? (
                  <p className="mechanics-note">
                    Bases de Vitalidade e recurso aguardam a tabela completa da classe.
                  </p>
                ) : null}

                <footer className="character-card-actions">
                  <Link
                    className="button button-primary"
                    href={"/personagem/" + character.id}
                  >
                    Abrir ficha
                  </Link>
                  <Button
                    variant="secondary"
                    onClick={() => exportCharacter(character.id)}
                  >
                    Exportar Markdown
                  </Button>
                  <div className="secondary-actions">
                    <Button
                      variant="ghost"
                      onClick={() => duplicateCharacter(character.id)}
                    >
                      Duplicar
                    </Button>
                    <Button
                      variant="ghost"
                      disabled={character.status === "linked"}
                      onClick={() => archiveCharacter(character.id)}
                    >
                      Arquivar
                    </Button>
                  </div>
                </footer>
              </article>
            );
          })}
        </div>
      ) : (
        <EmptyMessage title="Nenhum personagem neste filtro">
          Crie um personagem ou escolha outra situação da biblioteca.
        </EmptyMessage>
      )}
    </>
  );
}
