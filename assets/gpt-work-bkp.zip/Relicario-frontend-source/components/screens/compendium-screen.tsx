"use client";

import { useState } from "react";
import {
  ATTRIBUTES,
  CLASSES,
  CONDITIONS,
  MARITIME_TERRITORIES,
  REGIONS,
  SPECIALTIES,
} from "@/data/relicario";
import { PageHeader, SectionCard, StatusTag } from "@/components/ui";

type CompendiumTab =
  | "Classes"
  | "Atributos"
  | "Especialidades"
  | "Condições"
  | "Regiões"
  | "Regras";

export function CompendiumScreen() {
  const [tab, setTab] = useState<CompendiumTab>("Classes");
  const tabs: CompendiumTab[] = [
    "Classes",
    "Atributos",
    "Especialidades",
    "Condições",
    "Regiões",
    "Regras",
  ];

  return (
    <>
      <PageHeader
        eyebrow="Compêndio"
        title="Referência do sistema"
        description="Consulta rápida das decisões mecânicas e geográficas aprovadas para o Relicário."
      />

      <nav className="compendium-tabs" aria-label="Seções do compêndio">
        {tabs.map((item) => (
          <button
            key={item}
            type="button"
            className={tab === item ? "active" : ""}
            onClick={() => setTab(item)}
          >
            {item}
          </button>
        ))}
      </nav>

      {tab === "Classes" ? (
        <div className="compendium-class-grid">
          {CLASSES.map((item, index) => (
            <article
              key={item.name}
              style={{ "--class-accent": item.accent } as React.CSSProperties}
            >
              <span>{String(index + 1).padStart(2, "0")}</span>
              <h2>{item.name}</h2>
              <p>
                Recurso de classe: <strong>{item.resource}</strong>
              </p>
              <small>Classe aprovada do sistema próprio</small>
            </article>
          ))}
        </div>
      ) : null}

      {tab === "Atributos" ? (
        <SectionCard eyebrow="Distribuição inicial" title="3, 2, 1, 1 e 0">
          <div className="compendium-attribute-list">
            {ATTRIBUTES.map((attribute, index) => (
              <article key={attribute}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <strong>{attribute}</strong>
              </article>
            ))}
          </div>
        </SectionCard>
      ) : null}

      {tab === "Especialidades" ? (
        <SectionCard eyebrow="Lista aprovada" title="Especialidades">
          <div className="specialty-list compendium-specialties">
            {SPECIALTIES.map((specialty) => (
              <span key={specialty}>{specialty}</span>
            ))}
          </div>
        </SectionCard>
      ) : null}

      {tab === "Condições" ? (
        <SectionCard eyebrow="Estado mecânico" title="Condições">
          <div className="condition-reference">
            {CONDITIONS.map((condition, index) => (
              <article key={condition}>
                <span>{index + 1}</span>
                <strong>{condition}</strong>
              </article>
            ))}
          </div>
        </SectionCard>
      ) : null}

      {tab === "Regiões" ? (
        <div className="region-reference-layout">
          <SectionCard eyebrow="Auren" title="Nove regiões">
            <div className="region-reference-list">
              {REGIONS.map((region, index) => (
                <article key={region.name}>
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <div>
                    <strong>{region.name}</strong>
                    <small>{region.metropolis}</small>
                  </div>
                </article>
              ))}
            </div>
          </SectionCard>
          <SectionCard eyebrow="Mar" title="Territórios marítimos">
            <ul className="record-list">
              {MARITIME_TERRITORIES.map((territory) => (
                <li key={territory}>
                  <span className="record-mark" />
                  {territory}
                </li>
              ))}
            </ul>
          </SectionCard>
        </div>
      ) : null}

      {tab === "Regras" ? (
        <div className="rules-grid">
          <SectionCard eyebrow="Testes" title="1d20 + atributo + especialidade">
            <div className="difficulty-row">
              {[8, 11, 14, 17, 20].map((difficulty) => (
                <span key={difficulty}>{difficulty}</span>
              ))}
            </div>
            <p className="formula-note">Dificuldades aprovadas para os testes.</p>
          </SectionCard>
          <SectionCard eyebrow="Valores derivados" title="Fórmulas">
            <ul className="formula-list">
              <li>
                <span>Vitalidade máxima</span>
                <strong>base da classe + Força × 2 + Instinto</strong>
              </li>
              <li>
                <span>Recurso máximo</span>
                <strong>recurso-base + atributo principal</strong>
              </li>
              <li>
                <span>Defesa</span>
                <strong>8 + Agilidade + Instinto</strong>
              </li>
              <li>
                <span>Inventário</span>
                <strong>5 + Força × 2</strong>
              </li>
            </ul>
          </SectionCard>
          <SectionCard eyebrow="Combate" title="Quatro zonas">
            <div className="zone-tags">
              {["Corpo a corpo", "Perto", "Distante", "Fora de alcance"].map((zone) => (
                <StatusTag key={zone} tone="neutral">
                  {zone}
                </StatusTag>
              ))}
            </div>
            <p className="formula-note">Ataque e dano são separados.</p>
          </SectionCard>
        </div>
      ) : null}
    </>
  );
}
